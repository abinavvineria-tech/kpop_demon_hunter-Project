#!/usr/bin/env python3
"""
Huntrix Game
A word search game using the dialog library for Termux
"""

import random
import string
import os
import sys
import subprocess

class HuntrixGame:
    def __init__(self, size=8, words=None):
        self.size = size
        self.words = words or ["PYTHON", "CODE", "GAME", "TERMUX", "DIALOG", "HUNT", "WORD", "GRID"]
        self.grid = []
        self.found_words = []
        self.score = 0
        self.create_grid()
        self.place_words()
        self.fill_empty_spaces()

    def create_grid(self):
        """Create an empty grid"""
        self.grid = [[' ' for _ in range(self.size)] for _ in range(self.size)]

    def place_words(self):
        """Place words in the grid in various directions"""
        directions = [
            (0, 1),   # right
            (1, 0),   # down
            (1, 1),   # diagonal down-right
            (1, -1),  # diagonal down-left
        ]

        for word in self.words:
            placed = False
            attempts = 0
            while not placed and attempts < 100:
                direction = random.choice(directions)
                row = random.randint(0, self.size - 1)
                col = random.randint(0, self.size - 1)

                if self.can_place_word(word, row, col, direction):
                    self.place_word(word, row, col, direction)
                    placed = True
                attempts += 1

    def can_place_word(self, word, row, col, direction):
        """Check if a word can be placed at the given position"""
        dr, dc = direction
        for i, letter in enumerate(word):
            r, c = row + i * dr, col + i * dc
            if r < 0 or r >= self.size or c < 0 or c >= self.size:
                return False
            if self.grid[r][c] != ' ' and self.grid[r][c] != letter:
                return False
        return True

    def place_word(self, word, row, col, direction):
        """Place a word in the grid"""
        dr, dc = direction
        for i, letter in enumerate(word):
            r, c = row + i * dr, col + i * dc
            self.grid[r][c] = letter

    def fill_empty_spaces(self):
        """Fill empty spaces with random letters"""
        for i in range(self.size):
            for j in range(self.size):
                if self.grid[i][j] == ' ':
                    self.grid[i][j] = random.choice(string.ascii_uppercase)

    def display_grid(self):
        """Display the grid as a string"""
        result = ""
        result += "  " + " ".join([str(i) for i in range(self.size)]) + "\n"
        for i, row in enumerate(self.grid):
            result += str(i) + " " + " ".join(row) + "\n"
        return result

    def check_word(self, word):
        """Check if word is in the word list and not already found"""
        word = word.upper()
        if word in self.words and word not in self.found_words:
            self.found_words.append(word)
            self.score += len(word) * 10
            return True
        return False

    def game_status(self):
        """Return game status information"""
        return f"Score: {self.score} | Found: {len(self.found_words)}/{len(self.words)}"

def show_grid_dialog(game):
    """Show the game grid in a dialog"""
    grid_text = game.display_grid()
    status = game.game_status()

    try:
        subprocess.run([
            'dialog', '--title', 'Huntrix Game',
            '--msgbox', f"{status}\n\n{grid_text}\nUse arrow keys to navigate. Enter words you find.",
            '20', '50'
        ], stderr=subprocess.DEVNULL)
    except FileNotFoundError:
        print("Dialog not found. Please install dialog: pkg install dialog")
        sys.exit(1)

def get_word_input():
    """Get word input from user"""
    try:
        result = subprocess.run([
            'dialog', '--title', 'Enter Word',
            '--inputbox', 'Enter a word you found:',
            '8', '40'
        ], capture_output=True, text=True, stderr=subprocess.PIPE)

        if result.returncode == 0:
            return result.stderr.strip()
        else:
            return None
    except FileNotFoundError:
        print("Dialog not found. Please install dialog: pkg install dialog")
        sys.exit(1)

def show_message(title, message):
    """Show a message dialog"""
    try:
        subprocess.run([
            'dialog', '--title', title,
            '--msgbox', message,
            '10', '50'
        ], stderr=subprocess.DEVNULL)
    except FileNotFoundError:
        print("Dialog not found. Please install dialog: pkg install dialog")
        sys.exit(1)

def show_help():
    """Show game instructions"""
    help_text = """HUNTRIX GAME INSTRUCTIONS:

1. Find words hidden in the letter grid
2. Words can be horizontal, vertical, or diagonal
3. Enter words you find using the input dialog
4. Each letter is worth 10 points
5. Find all words to win!

Controls:
- OK/Enter: Confirm selections
- Cancel/Esc: Exit game
- Arrow keys: Navigate dialogs

Press OK to start playing!"""

    try:
        subprocess.run([
            'dialog', '--title', 'Huntrix Help',
            '--msgbox', help_text,
            '20', '60'
        ], stderr=subprocess.DEVNULL)
    except FileNotFoundError:
        print("Dialog not found. Please install dialog: pkg install dialog")
        sys.exit(1)

def main():
    """Main game loop"""
    # Show welcome message
    try:
        subprocess.run([
            'dialog', '--title', 'Welcome to Huntrix',
            '--yesno', 'Welcome to Huntrix! A word search game for Termux.\n\nWould you like to play?',
            '10', '50'
        ], stderr=subprocess.DEVNULL)
    except FileNotFoundError:
        print("Dialog not found. Please install dialog: pkg install dialog")
        sys.exit(1)

    # Show help
    show_help()

    # Initialize game
    game = HuntrixGame()

    # Main game loop
    while len(game.found_words) < len(game.words):
        # Show grid
        show_grid_dialog(game)

        # Get word input
        word = get_word_input()
        if word is None:
            # User cancelled
            try:
                result = subprocess.run([
                    'dialog', '--title', 'Exit',
                    '--yesno', 'Are you sure you want to exit?',
                    '6', '40'
                ], stderr=subprocess.DEVNULL)
                if result.returncode == 0:
                    show_message("Goodbye", f"Final Score: {game.score}\nWords Found: {len(game.found_words)}/{len(game.words)}")
                    return
                else:
                    continue
            except FileNotFoundError:
                break

        # Check word
        if game.check_word(word):
            show_message("Correct!", f"Found word: {word}\n+{len(word)*10} points!")
        else:
            show_message("Try Again", f"'{word}' is not a valid word or already found.")

    # Game completed
    show_message("Congratulations!", f"You found all words!\nFinal Score: {game.score}")

if __name__ == "__main__":
    main()
